USE tempdb;
GO
DROP DATABASE IF EXISTS lab5_db;
GO
CREATE DATABASE lab5_db;
GO
USE lab5_db;
GO
EXEC sp_changedbowner 'sa';
GO

CREATE TABLE team(
	teamId			INT IDENTITY(1, 1),
	teamName		VARCHAR(25),
	teamCity		VARCHAR(35),
	teamRank		TINYINT,
	teamActive		BIT,
	teamManager		VARCHAR(20),
	teamManagerCity	VARCHAR(35),
	teamFormedDate	DATE,
	CONSTRAINT pk_team_teamId PRIMARY KEY (teamId)
);
INSERT INTO team
VALUES
	('Cha Cha Cha',			'Thorold',				5,	1,	'Sandy Smith',		'Toronto',			'2022-01-24'),
	('Cool Sky Flower',		'Niagara Falls',		4,	1,	'Sophie Willow',	'Welland',			'2021-04-30'),
	('Creamy Pointy',		'Niagara Falls',		1,	1,	'Katie Lee',		'Throld',			'2022-01-08'),
	('Cute Shark',			'Toronto',				1,	1,	'Jack Sanderson',	'St Cathrines',		'2021-12-18'),
	('Dot Dot Business',	'Niagara-on-the-Lake',	2,	1,	'Tom King',			'Thorold',			'2021-10-30'),
	('Easy Creep',			'Welland',				3,	0,	'Nancy Boulter',	'Regina',			'2021-03-16'),
	('Green Power',			'Thorold',				2,	0,	'Jackie Smith',		'Welland',			'2020-09-30'),
	('Squat Star Power',	'St Catharines',		4,	1,	'Steve Jenkins',	'Niagara Falls',	'2021-02-26'),
	('Smart Cholestoral',	'Grimysby',				2,	1,	'Frank King',		'Thorold',			'2020-08-31'),
	('Zig Zag Torpedo',		'Hamilton',				1,	0,	'Gilbert Wolfe',	'NOTL',				'2020-12-02');


CREATE TABLE player(
	playerId			INT IDENTITY(1, 1),
	playerUserId		VARCHAR(20),
	playerTitle			VARCHAR(15),
	playerFirstName		VARCHAR(25) NOT NULL,
	playerLastName		VARCHAR(30) NOT NULL,
	playerQuizDate		DATE,
	playerStreet		VARCHAR(35),
	playerCity			VARCHAR(40),
	playerProvince		VARCHAR(45),
	playerPhone			CHAR(10),
	playerIsVideoGame	BIT,
	playerIncome		DECIMAL(12, 2),
	teamId INT,
	CONSTRAINT pk_player_playerId PRIMARY KEY (playerId),
	CONSTRAINT fk_player_team FOREIGN KEY (teamId) REFERENCES team (teamId) ON DELETE SET NULL
);
INSERT INTO player
VALUES
	('Amelia_Ray',			'Ms',	'Amelia',		'Ray',			'2020-09-07',	'4198 James Street',	'St Catharines',	'Ontario',			'9056825216',	1,		100378.38,	2),
	('David_Herd',			'Mr',	'David',		'Herd',			'2020-09-13',	'1843 St. Paul Street',	'Niagara Falls',	'Ontario',			'9053711255',	1,		99568.88,	10),
	('Mike_Slavinjak',		'Mr',	'Mike',			'Slavinjak',	'2020-09-24',	'29 Palace Street',		'Niagara Falls',	'Ontario',			'9053741378',	1,		123862.79,	3),
	('Merrill_Choudhry',	'Mr',	'Merrill',		'Choudhry',		'2020-10-06',	'4765 Maria St',		'Burlington',		'Ontario',			'9056399996',	1,		99896.16,	4),
	('Sophia_Wardle',		'Miss',	'Sophia',		'Wardle',		'2020-10-08',	'1844 Ontario St',		'St Catharines',	'Ontario',			'9056461165',	1,		139638.57,	4),
	('Mia_Ho',				'Miss',	'Mia',			'Ho',			'2020-10-09',	'22 Gracefield Avenue',	'Thorold',			'Ontario',			'9053542704',	1,		79698.98,	7),
	('Charlotte_Nijjar',	'Mrs',	'Charlotte',	'Nijjar',		'2021-01-24',	'4012 St. Paul Street',	'St Catharines',	'Ontario',			'9053589981',	1,		86397.28,	9),
	('Ryan_Li',				'Mr',	'Ryan',			'Li',			'2021-02-27',	'658 Rose Street',		'Regina',			'Saskatchewan',		'3065459237',	1,		178651.39,	4),
	('Emma_Houle',			'Ms',	'Emma',			'Houle',		'2021-02-27',	'1365 Weir Crescent',	NULL,				NULL,				'9056320269',	1,		96872.56,	4),
	('Olivia_Maas',			'Miss',	'Olivia',		'Maas',			'2021-03-27',	'734 James Street',		'St Catharines',	'Ontario',			'9053359062',	1,		123987.68,	4),
	('Darren_Muetz',		'Mr',	'Darren',		'Muetz',		'2021-04-19',	'717 Ontario St',		'Toronto',			'Ontario',			'9058023124',	1,		121268.37,	5),
	('Nancy_Combe',			'Mrs',	'Nancy',		'Combe',		'2021-09-13',	'63 Adelaide St',		'Toronto',			'Ontario',			'4169806097',	1,		89637.36,	6),
	('Stephen_Shock',		'Mr',	'Stephen',		'Shock',		'2021-10-18',	'48 George ST',			'Thorold',			'Ontario',			'9056390805',	0,		99965.23,	8),
	('Julianna_Smith',		'Mrs',	'Julianna',		'Smith',		'2021-10-21',	NULL,					'Niagara Falls',	'Ontario',			'6478696345',	1,		116872.63,	8),
	('Ava_Creamer',			'Mrs',	'Ava',			'Creamer',		'2022-01-06',	'213 Barton Street',	'Hamilton',			'Ontario',			'4164912619',	1,		110268.37,	NULL),
	('Kyle_Edwards',		'Mr',	'Kyle',			'Edwards',		'2022-01-07',	'3393 Maria St',		'St Catharines',	'ON',				'6472975094',	1,		98365.29,	NULL);

--SELECT * FROM team;
--SELECT * FROM player;

DECLARE @team_json NVARCHAR(MAX)
SET @team_json = '[
    {
        "team_id": 11,
        "name": "10^3 Giant Goal",
        "city": "Welland",
        "rank": 2,
        "active": true,
        "manager_name": "Joe Doe",
        "manager_city": "Welland",
        "formed_date": "2020-09-01"
	},
	{
        "team_id": 12,
        "name": "Unfrozen Snowman",
        "city": "St Catharines",
        "rank": 3,
        "active": false,
        "manager_name": "Jane Doe",
        "manager_city": "Niagara Falls",
        "formed_date": "2020-10-30"
	}]'

--SELECT * FROM OPENJSON(@team_json)

DECLARE @player_json NVARCHAR(MAX)
SET @player_json = '[
            {
                "player_id": 21,
                "user_id": "Jennifer_Boucher",
                "title": "Ms",
                "first_name": "Jennifer",
                "last_name": "Boucher",
                "quiz_date": "2020-09-08",
                "street": "17 Devine Cresccent",
                "city": "Thorold",
                "province": "Ontario",
                "phone": "9054012463",
                "is_video_game": true,
                "income": 96873.58
            },
            {
                "player_id": 22,
                "user_id": "Fernando_Gross",
                "title": "Mr",
                "first_name": "Fernando",
                "last_name": "Gross",
                "quiz_date": "2020-12-21",
                "street": "11 Pine St South",
                "city": "Thorold",
                "province": "Ontario",
                "phone": "9053514629",
                "is_video_game": true,
                "income": 162572.62
            },
            {
                "player_id": 23,
                "user_id": "Andrew_Strilec",
                "title": "Mr",
                "first_name": "Andrew",
                "last_name": "Strilec",
                "quiz_date": "2022-01-07",
                "street": "3203 Lake City Way",
                "city": "Burnaby",
                "province": "British Columbia",
                "phone": "6046127958",
                "is_video_game": true,
                "income": 88956.49
            },
			{
                "player_id": 24,
                "user_id": "Merrill_Macrillo",
                "title": "Mr",
                "first_name": "Merrill",
                "last_name": "Macrillo",
                "quiz_date": "2022-01-10",
                "street": null,
                "city": null,
                "province": null,
                "phone": "4163648816",
                "is_video_game": null,
                "income": 89672.38
            }]'

--SELECT * FROM OPENJSON(@player_json)

SELECT * FROM team 
CROSS APPLY OPENJSON(@team_json)

SELECT * FROM player
CROSS APPLY OPENJSON(@player_json)

