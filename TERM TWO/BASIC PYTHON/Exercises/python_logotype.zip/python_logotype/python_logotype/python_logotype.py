length = 11
prog = "CP/CPA"
width = length * 3

nums  = range(1,length,2)
top = [("*|*" * n).center(width, "-") for n in nums]
middle = prog.center(width, "-")
bottom = top[-1::-1]
final = top + [middle] + bottom #[middle] is a list
for f in final: #making a loop for dividing lines
    print(f)
