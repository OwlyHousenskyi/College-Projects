def pokemon():
  return [
      {
        "pokemon": "Greninja",
        "stamina": 12,
        "attack": 13,
        "defense": 9,
        "battled": [ "Lucario", "Sylveon" ]
      },
      {
        "pokemon": "Lucario",
        "stamina": 11,
        "attack": 10,
        "defense": 14,
        "battled": [ "Greninja" ]
      },
      {
        "pokemon": "Garchomp",
        "stamina": 5,
        "attack": 6,
        "defense": 8,
        "battled": [ "Sylveon", "Greninja" ]
      },
      {
        "pokemon": "Sylveon",
        "stamina": 5,
        "attack": 6,
        "defense": 8,
        "battled": [ "Garchomp", "Greninja" ]
      }
  ]
