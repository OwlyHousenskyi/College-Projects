from pokedex import pokemon
from logic import *
pokemon_list = pokemon()

#you can remove this line of code once you familiarize yourself with the pokemon variable
#print(pokemon())

menu = ("\n1. Show all Pokemon\n2. Find Pokemon Stats\n3. Exit\n\n")
choice = input(menu)

while True:
    if choice == "1":
        result = show_all_pokemon(pokemon_list)
    elif choice == "2":
        result = find_pokemon_stats(pokemon_list)
    elif choice == "3":
        exit(print("Goodbye!"))
    else:
        print("Invalid")
        
    input(f"{result}\n\nPress any key to continue...")
    choice = input(menu)
