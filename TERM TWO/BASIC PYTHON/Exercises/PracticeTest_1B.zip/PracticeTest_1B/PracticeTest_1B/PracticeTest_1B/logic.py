from pokedex import pokemon

# button 1 :
def show_all_pokemon(pokedex)->list:
    all_pokemons = map(lambda p: f'{p.get("pokemon")}, battled : {format_pokemons(p.get("battled"))}', pokemon())
    return "\n".join(all_pokemons)

# formatting for button 1:
def format_pokemons(times)->str:
    return ", ".join(sorted(times))

# button 2 :
# stats into "%" : stats / 15 * 100 
def find_pokemon_stats(pokedex)->list:
    found_pokemon = []
    pokemon_list = pokemon()
    input_name = input("Enter a pokemon name: ")
    for s in pokemon_list:
        if s['pokemon'] == input_name:
            stamina_per = "{:.2f}".format(s['stamina'] / 15 * 100)
            attack_per = "{:.2f}".format(s['attack'] / 15 * 100)
            defense_per = "{:.2f}".format(s['defense'] / 15 * 100)
            found_pokemon.append(f"Stamina: {stamina_per}%({s['stamina']})\nAttack: {attack_per}%({s['attack']})\nDefense: {defense_per}%({s['defense']})")
            break
    else:
        return "Pokemon not in a list"
    return "\n".join(found_pokemon)




        
    

