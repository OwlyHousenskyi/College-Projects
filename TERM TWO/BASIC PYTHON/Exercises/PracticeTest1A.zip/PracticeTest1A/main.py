
import random

def get_deckparts():
    return {
        "suits": ["H", "D", "S", "C"],
        "cards": ["2","3","4","5","6","7","8","9","10","J","Q","K","A"]
    }
#1
deckparts = get_deckparts()
fullarray = []
for suits in deckparts["suits"]:
    for cards in deckparts["cards"]:
        fullarray.append(suits + cards)
print(fullarray,"\n")

#2
def randomize_five_nums():
    five_nums = random.sample(fullarray, 5)
    print(five_nums,"\n")
randomize_five_nums()

#3
def obrain_flush():
    print(f"It took ... deals to obtain a flush")
    print(f"Here is the resulting hand: ...")
obrain_flush()