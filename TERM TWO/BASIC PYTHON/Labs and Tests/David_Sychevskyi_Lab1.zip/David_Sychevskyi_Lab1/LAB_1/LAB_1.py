
import random

def generate_rand_nums(low, high):
    random_nums = []
    for n in range(5):
        random_num = random.randint(low, high)
        random_nums.append(random_num)
    return random_nums

firstquest = input("Enter a low and high number, separated by a space, for generating values: ")
low, high = map(int, firstquest.split())

secondquest = int(input("Enter a search number: "))
sets_of_rand_nums = []

for m in range(secondquest):
    random_nums = generate_rand_nums(low, high)
    sets_of_rand_nums.append(random_nums)

counter = []

for i, random_nums in enumerate(sets_of_rand_nums):
    random_nums_str = " ".join(map(str, random_nums))
    for x in random_nums:
        if x == secondquest:
            counter.append(1)
    print(random_nums_str)

def mul_or_not():
    if len(counter) > 1:
        print(f"The number {secondquest} was found {str(len(counter))} times in {secondquest} sets of random numbers")
    else:
        print(f"The number {secondquest} was found {str(len(counter))} time in {secondquest} sets of random numbers")

mul_or_not()





