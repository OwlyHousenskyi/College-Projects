def get_quiz()->list:
    return [
       {
           "question": "What is your favorite color?",
           "correct": "A",
           "answers": ["A. blue", "B. red", "C. green", "D. voilet"]
       },
       {
           "question": "What is the airspeed velocity of an unladen swallow (miles/hr)?",
           "correct":  "D",
           "answers": ["A. 100", "B. 1.1", "C. 200", "D. 20.1"]
       },
       {
           "question": "What is the capital of Assyria?",
           "correct":  "C",
           "answers": ["A. Nimrud", "B. Nineveh", "C. Assur", "D. Harran"]
       },
       {
           "question": "What is your quest?",
           "correct":  "B",
           "answers": ["A. Bridgekeeping", "B. To seek the Holy Grail", "C. To Become the King of the Britons", "D. To be a Lumberjack"]
       }
        
    ]
