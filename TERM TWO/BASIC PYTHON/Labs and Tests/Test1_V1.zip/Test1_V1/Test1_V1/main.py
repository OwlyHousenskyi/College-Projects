from quiz import get_quiz

print("Welcome to quiz game!\nNOTE: If you spell it incorrect, you are not reciving the score\n")

score = 0
award = 0
question_list = get_quiz()
for q in question_list:
    print(f"\n{q['question']}")
    print("\n".join(a for a in q['answers']))
    choice = input("\nSelect the correct answer (A,B,C, or D): ")
    if choice == q['correct']:
        score += 25.0
        if score >= 75.0:
            award = "The Holy Hand Grenade of Antioch"
        elif score >= 50.0 or score <= 75.0:
            award = "A Complimentary Shrubbery"
        else:
            award = "Eldenberries"
print(f"You scored {score}% on this quiz. You have been awarded {award} of Your Choice!")

        
