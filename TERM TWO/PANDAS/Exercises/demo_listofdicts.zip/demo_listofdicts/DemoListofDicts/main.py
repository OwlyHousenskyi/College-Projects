from beer import get_beer
from os import system
from search_funcs import *
beer_list = get_beer()

menu = "1.Actively Brewed Beer\
\n2.Beer Name and Flavors\
\n3.Average IBU and ABV Values\n4.Exit\n\n"
choice = input(menu)

while True:    
    if choice == "1":
        result = find_by_status(True, beer_list)
    elif choice == "2":
        result = show_flavors(beer_list)
    elif choice == "3":
        result = get_avgs(beer_list)
    elif choice == "4":
        exit()
    else:
        print("invalid")
    
    input (f"{result}\n\nPress any key to continue...")
    system("cls")
    choice = input(menu)