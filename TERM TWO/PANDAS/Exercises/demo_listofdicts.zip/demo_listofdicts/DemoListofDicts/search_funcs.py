def find_by_status(isActive:bool, beer)->list:
    #items =[f'{b.get("breweryName")}: {b.get("name")}'
    #            for b in beer 
    #            if b.get("activelyBrewed") == isActive]
    items = filter(lambda b:b.get("activelyBrewed") == isActive, beer)
    str_items = map(lambda b: f'{b.get("breweryName")}: {b.get("name")}',items)
    return "\n".join(str_items)

def format_flavors(flavors:list)->str:
    return ", ".join(sorted(flavors))

def show_flavors(beer:list)->list:
    beer.sort(key=lambda b:b.get("name"))
    items = map(lambda b:f'{b.get("name")}: {format_flavors(b.get("flavors"))}', beer)
    return "\n".join(items)

def get_avgs(beer:list)->dict:
    avg_ibu = sum([b.get("ibu") for b in beer])/len(beer)
    avg_abv = sum([b.get("abv") for b in beer])/len(beer)
    return dict(
                    AverageIBU = format(avg_ibu,".2f"), 
                    AverageABV = format(avg_abv,".2f")
                )