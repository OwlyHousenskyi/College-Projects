DROP DATABASE IF EXISTS p2_end
GO
CREATE DATABASE p2_end
GO
USE p2_end
GO

-- Task 1: Extract JSON Data
DECLARE @json NVARCHAR(MAX)
SELECT @json = BulkColumn
FROM OPENROWSET (BULK 'c:\project\p2_start_winery.json', SINGLE_CLOB) AS j
SELECT @json AS JsonData;

-- Task 2A:
DROP TABLE IF EXISTS #TempWinery
CREATE TABLE #TempWinery (jsonData NVARCHAR(MAX))
INSERT INTO #TempWinery VALUES (@json)

SELECT
    JSON_VALUE(jsonData, '$.farm_id') AS farm_id,
    JSON_VALUE(jsonData, '$.farm_name') AS farm_name,
    JSON_VALUE(jsonData, '$.farm_type') AS farm_type,
    JSON_VALUE(jsonData, '$.address.street.street_num') AS street_num,
    JSON_VALUE(jsonData, '$.address.street.street_name') AS street_name,
    JSON_VALUE(jsonData, '$.address.street.street_suffix') AS street_suffix,
    JSON_VALUE(jsonData, '$.address.street.street_dir') AS street_dir,
    JSON_VALUE(jsonData, '$.address.city') AS city,
    JSON_VALUE(jsonData, '$.address.prov_abbr') AS prov_abbr,
    JSON_VALUE(jsonData, '$.address.postal_code') AS postal_code,
    JSON_VALUE(jsonData, '$.location.latitude') AS latitude,
    JSON_VALUE(jsonData, '$.location.longitude') AS longitude
INTO TransformedWinerires
FROM #TempWinery;
DROP TABLE #TempWinery;

-- Task 2B: 
CREATE TABLE p2_end_wineries (
    farm_id INT PRIMARY KEY,
    farm_name NVARCHAR(255),
    farm_type NVARCHAR(255),
    street_num NVARCHAR(10),
    street_name NVARCHAR(255),
    street_suffix NVARCHAR(10),
    street_dir NVARCHAR(10),
    city NVARCHAR(255),
    prov_abbr NVARCHAR(2),
    postal_code NVARCHAR(10),
    latitude FLOAT,
    longitude FLOAT
);

INSERT INTO p2_end_wineries
SELECT * FROM TransformedWinerires;

-- Task 2C:
ALTER TABLE p2_end_wineries
ADD CONSTRAINT PK_p2_end_wineries PRIMARY KEY (farm_id);

