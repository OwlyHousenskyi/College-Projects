﻿using Dapper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.Storage;

namespace DavidSychevskyi_CanadaGames
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            LoadData();
        }

        private void ApplyFilters_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            var athletes = DatabaseHelper.GetFilteredAthletes(
                contingentComboBox.SelectedItem as string,
                genderComboBox.SelectedItem as string,
                nameSearchTextBox.Text,
                dobFromDate.Date.Date,
                dobToDate.Date.Date);

            athleteListView.ItemsSource = athletes;
        }

        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (athleteListView.SelectedItem is Athlete selectedAthlete)
            {
                bool confirmed = await ConfirmDeleteAthleteAsync(selectedAthlete);

                if (confirmed)
                {
                    int athleteId = selectedAthlete.AthleteId;
                    DeleteAthlete(athleteId);
                    LoadData();
                }
            }
        }

        private async Task<bool> ConfirmDeleteAthleteAsync(Athlete athlete)
        {
            var dialog = new ContentDialog
            {
                Title = "Confirm Deletion",
                Content = $"Are you sure you want to delete {athlete.FirstName} {athlete.LastName}?",
                PrimaryButtonText = "Delete",
                CloseButtonText = "Cancel"
            };
            ContentDialogResult result = await dialog.ShowAsync();
            return result == ContentDialogResult.Primary;
        }

        private void DeleteAthlete(int athleteId)
        {
            using (var connection = DatabaseHelper.GetOpenConnection())
            {
                string query = "DELETE FROM Athletes WHERE AthleteId = @AthleteId";
                connection.Execute(query, new { AthleteId = athleteId });
            }
        }

        private bool ValidateAthlete(Athlete athlete)
        {
            if (string.IsNullOrWhiteSpace(athlete.FirstName) || string.IsNullOrWhiteSpace(athlete.LastName))
            {
                return false;
            }
            return true;
        }

        private async void AccessSqlFile()
        {
            try
            {
                StorageFile sqlFile = await StorageFile.GetFileFromApplicationUriAsync(
                    new Uri("ms-appx:///Assets/Create_CanadaSummerGames_Simple_With Lab 4 -v3.sql"));

                string sqlContent = await FileIO.ReadTextAsync(sqlFile);
            }
            catch (FileNotFoundException)
            {
                return;
            }
            catch (Exception)
            {
                return;
            }
        }
    }
}
