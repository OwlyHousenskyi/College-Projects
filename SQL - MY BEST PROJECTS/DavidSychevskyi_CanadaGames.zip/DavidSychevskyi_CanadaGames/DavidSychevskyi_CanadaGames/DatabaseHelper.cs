﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace DavidSychevskyi_CanadaGames
{
    public static class DatabaseHelper
    {
        private static readonly string Database = "CanadaSummerGames_Simple";

        public static IDbConnection GetOpenConnection()
        {
            var connectionStringBuilder = new SqlConnectionStringBuilder
            {
                InitialCatalog = Database
            };
            var connection = new SqlConnection(connectionStringBuilder.ToString());
            connection.Open();
            return connection;
        }

        public static IEnumerable<Athlete> GetFilteredAthletes(
            string contingent, string gender, string nameSearch, DateTime? dobFrom, DateTime? dobTo)
        {
            using (var connection = GetOpenConnection())
            {
                var query = "SELECT * FROM Athletes WHERE 1 = 1";
                var parameters = new DynamicParameters();

                if (!string.IsNullOrEmpty(contingent))
                {
                    query += " AND Contingent = @Contingent";
                    parameters.Add("@Contingent", contingent);
                }

                if (!string.IsNullOrEmpty(gender))
                {
                    query += " AND Gender = @Gender";
                    parameters.Add("@Gender", gender);
                }

                if (!string.IsNullOrEmpty(nameSearch))
                {
                    query += " AND (FirstName LIKE @NameSearch OR LastName LIKE @NameSearch)";
                    parameters.Add("@NameSearch", "%" + nameSearch + "%");
                }

                if (dobFrom != null)
                {
                    query += " AND DOB >= @DOBFrom";
                    parameters.Add("@DOBFrom", dobFrom.Value.Date);
                }

                if (dobTo != null)
                {
                    query += " AND DOB <= @DOBTo";
                    parameters.Add("@DOBTo", dobTo.Value.Date);
                }

                return connection.Query<Athlete>(query, parameters);
            }
        }

        public static IEnumerable<string> GetDistinctContingents()
        {
            var connection = GetOpenConnection();
            return connection.Query<string>("SELECT DISTINCT Contingent FROM Athletes");
        }

        public static IEnumerable<string> GetDistinctGenders()
        {
            var connection = GetOpenConnection();
            return connection.Query<string>("SELECT DISTINCT Gender FROM Athletes");
        }
    }
}
